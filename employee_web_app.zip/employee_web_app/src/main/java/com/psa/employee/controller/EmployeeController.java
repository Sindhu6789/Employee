package com.psa.employee.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.psa.employee.entities.Employee;
import com.psa.employee.repositories.EmployeeRepository;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeRepository employeeRepo;
	
	
	@RequestMapping("/signUp")
	public String signUp() {
		return "signUp";
	}
	
	@RequestMapping("/saveDetails")
	public String saveDetails(@RequestParam("username") String  username,@RequestParam("emailid") String  emailid,@RequestParam("password") String  password,@RequestParam("cpassword") String  cpassword,ModelMap modelMap) {
		Employee employee=new Employee();
		employee.setUsername(username);
		employee.setEmail(emailid);
		employee.setPassword(password);
		employee.setCpassword(cpassword);
		
		employeeRepo.save(employee);		
		modelMap.addAttribute("msg", "Location Saved");
		return "signUp";
			
	}
	

}
