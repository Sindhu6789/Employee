package com.psa.employee.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import com.psa.employee.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, String> {


}
