package com.psa.employee.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.psa.employee.entities.Employee;
import com.psa.employee.repositories.EmployeeRepository;

@RestController
@RequestMapping("/employee")
public class EmployeeRestController {
 
	@Autowired
	private EmployeeRepository employeeRepo;
	
	
	@GetMapping(path="/findall")
	public  List<Employee> showSignUp() {
		List<Employee> list =employeeRepo.findAll();
		return list;
		}
	
	@PostMapping(path="/saveD")
	public String saveD(@RequestBody Employee employee,@RequestParam("username") String  username,@RequestParam("emailid") String  emailid,@RequestParam("password") String  password,@RequestParam("cpassword") String  cpassword) {
Employee emplyoee=new Employee();
		
		emplyoee.setEmail(emailid);
		emplyoee.setUsername(username);
		emplyoee.setPassword(password);
		emplyoee.setCpassword(cpassword);
		employeeRepo.save(emplyoee);
		return "signUp";

	}
	
	@DeleteMapping("/{id}")
	public void deleteDetails(@PathVariable("id") String id) {
		employeeRepo.deleteById(id);
	}
	
	@PutMapping
	public Employee updateDetails(@RequestBody Employee employee) {
		return employeeRepo.save(employee);

	}
	
	@GetMapping("{id}")
	public Employee showDetails(@PathVariable("id") String id) {
		Optional<Employee> findById = employeeRepo.findById(id);
		Employee employee=findById.get();
		return employee;
		
	}
	
	 
	
	
}
