package com.psa.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
